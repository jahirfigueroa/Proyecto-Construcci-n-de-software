
package Modelo;

public class Combo {
    // Atributos de la clase Combo
    private int id;
    private String nombre;

    // Constructor con parámetros para inicializar todos los campos
    public Combo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }
    // Creacion de los metodos getter y setter para obtener los valores de los diferentes atributos
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public String toString(){
        return this.getNombre();
    }
}
