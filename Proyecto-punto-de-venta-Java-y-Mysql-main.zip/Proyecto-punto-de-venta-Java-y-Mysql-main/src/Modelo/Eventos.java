package Modelo;

import java.awt.event.KeyEvent;
import javax.swing.JTextField;

public class Eventos {
    
// Método para permitir únicamente letras y espacios en un campo de texto
    public void textKeyPress(KeyEvent evt) {
        char car = evt.getKeyChar();
        if ((car < 'a' || car > 'z') && (car < 'A' || car > 'Z')
                && (car != (char) KeyEvent.VK_BACK_SPACE) && (car != (char) KeyEvent.VK_SPACE)) {
            evt.consume();// Consumir el evento si el carácter no es una letra o espacio
        }
    }
    // Método para permitir únicamente números en un campo de texto
    public void numberKeyPress(KeyEvent evt) {
        char car = evt.getKeyChar();
        if ((car < '0' || car > '9') && (car != (char) KeyEvent.VK_BACK_SPACE)) {
            evt.consume();// Consumir el evento si el carácter no es un número
        }
    }
// Método para permitir únicamente números y un solo punto decimal en un campo de texto
    public void numberDecimalKeyPress(KeyEvent evt, JTextField textField) {
        char car = evt.getKeyChar();
        if ((car < '0' || car > '9') && textField.getText().contains(".") && (car != (char) KeyEvent.VK_BACK_SPACE)) {
            evt.consume();// Consumir el evento si el carácter no es un número o si ya hay un punto decimal
        } else if ((car < '0' || car > '9') && (car != '.') && (car != (char) KeyEvent.VK_BACK_SPACE)) {
            evt.consume();// Consumir el evento si el carácter no es un número ni un punto decimal
        }
    }
}
