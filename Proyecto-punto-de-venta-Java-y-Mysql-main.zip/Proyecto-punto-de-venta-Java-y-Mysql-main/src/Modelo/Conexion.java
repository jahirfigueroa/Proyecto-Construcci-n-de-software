package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    Connection con;  // Objeto Connection para la conexión a la base de datos

    // Método para obtener la conexión a la base de datos
    public Connection getConnection() {
        try {
            // Configuración de la cadena de conexión con la base de datos MySQL
            String myBD = "jdbc:mysql://localhost:3306/proyecto";
            
            // Establecer conexión utilizando el controlador JDBC de MySQL
            con = DriverManager.getConnection(myBD, "root", ""); 
            
            // Devolver la conexión establecida
            return con;
        } catch (SQLException e) {
            // Manejo de excepciones en caso de error durante la conexión
            System.out.println(e.toString());
        }
        // Devolver null en caso de fallo en la conexión
        return null;
    }

} 
