
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Login_Des {
    Connection con;// Objeto Connection para la conexión a la base de datos
    PreparedStatement ps;// Objeto PreparedStatement para ejecutar consultas preparadas
    ResultSet rs;// Objeto ResultSet para almacenar resultados de consultas
    Conexion cn = new Conexion();// Instancia de la clase de conexión a la base de datos
    
    // Método para realizar el inicio de sesión
    public login log(String correo, String pass){
        login l = new login();
        String sql = "SELECT * FROM usuarios WHERE correo = ? AND pass = ?";
        try {
            con = cn.getConnection();// Establecer conexión
            ps = con.prepareStatement(sql);// Preparar la consulta SQL
            ps.setString(1, correo);// Establecer valores para los parámetros
            ps.setString(2, pass);
            rs= ps.executeQuery();// Ejecutar la consulta
            if (rs.next()) {
                // Establecer valores en el objeto login si se encuentra una coincidencia
                l.setId(rs.getInt("id"));
                l.setNombre(rs.getString("nombre"));
                l.setCorreo(rs.getString("correo"));
                l.setPass(rs.getString("pass"));
                l.setRol(rs.getString("rol"));
                
            }
        } catch (SQLException e) {
            System.out.println(e.toString()); // Mostrar mensaje en caso de error
        }
        return l;
    }
    // Método para registrar un nuevo usuario
    public boolean Registrar(login reg){
        String sql = "INSERT INTO usuarios (nombre, correo, pass, rol) VALUES (?,?,?,?)";
        try {
            con = cn.getConnection();// Establecer conexión
            ps = con.prepareStatement(sql);// Preparar la consulta SQL
            // Establecer valores para los parámetros
            ps.setString(1, reg.getNombre());
            ps.setString(2, reg.getCorreo());
            ps.setString(3, reg.getPass());
            ps.setString(4, reg.getRol());
            ps.execute(); // Ejecutar la consulta
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());// Mostrar mensaje en caso de error
            return false;
        }
    }
    // Método para obtener la lista de todos los usuarios
    public List ListarUsuarios(){
       List<login> Lista = new ArrayList();
       String sql = "SELECT * FROM usuarios";
       try {
           con = cn.getConnection();// Establecer conexión
           ps = con.prepareStatement(sql); // Preparar la consulta SQL
           rs = ps.executeQuery(); // Ejecutar la consulta
           while (rs.next()) {               
               login lg = new login();
                // Establecer valores en objetos login y agregarlos a la lista
               lg.setId(rs.getInt("id"));
               lg.setNombre(rs.getString("nombre"));
               lg.setCorreo(rs.getString("correo"));
               lg.setRol(rs.getString("rol"));
               Lista.add(lg);
           }
       } catch (SQLException e) {
           System.out.println(e.toString());// Mostrar mensaje en caso de error
       }
       return Lista;
   }
}
